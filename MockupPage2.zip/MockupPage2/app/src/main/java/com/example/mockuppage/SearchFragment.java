package com.example.mockuppage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import java.util.ArrayList;

public class SearchFragment extends Fragment {

    private ArrayList<ExampleItem> mExampleList;

    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_search, container, false);

        createExampleList();
        buildRecyclerView();

        EditText editText = v.findViewById(R.id.edittext);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });

        return v;

    }

    private void filter(String text) {
        ArrayList<ExampleItem> filteredList = new ArrayList<>();

        for (ExampleItem item : mExampleList) {
            if (item.getText1().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }

        mAdapter.filterList(filteredList);
    }

    private void createExampleList() {
        mExampleList = new ArrayList<>();
        mExampleList.add(new ExampleItem(R.drawable.ic_android, "Doom", "First-Person-Shooter"));
        mExampleList.add(new ExampleItem(R.drawable.ic_assessment, "Donkey Kong", "Action/Adventure"));
        mExampleList.add(new ExampleItem(R.drawable.ic_cloud_upload, "Mortal Kombat", "Fighting"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android, "Resident Evil", "Survival"));
        mExampleList.add(new ExampleItem(R.drawable.ic_assessment, "RuneScape", "MMORPG"));
        mExampleList.add(new ExampleItem(R.drawable.ic_cloud_upload, "League of Legends", "MOBA"));
        mExampleList.add(new ExampleItem(R.drawable.ic_android, "Rogue Legacy", "Roguelike"));
        mExampleList.add(new ExampleItem(R.drawable.ic_assessment, "Garry's Mod", "Sandbox"));
        mExampleList.add(new ExampleItem(R.drawable.ic_cloud_upload, "Age of Empires", "RTS"));
    }

    private void buildRecyclerView() {
       // mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
       // mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }
    }

